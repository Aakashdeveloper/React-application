# This is Both FrontEnd and BackEnd part of the application
