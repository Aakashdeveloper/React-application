// import React,{Component} from 'react';
// import Header from '../Header/header';


// class CustomerBookings extends Component{

//     constructor(){

//         super()

//         this.state={

//         }
//     }

//     render(){

//         return(
//             <React.Fragment>
//                 <Header/>
//                 <h1 className="text-center">Customer Bookings </h1>
//             </React.Fragment>
//         )
//     }
// }

// export default CustomerBookings;