import React from 'react';

const Footer =()=>{
    return(
        <React.Fragment>
            <footer className="bg-light text-center">
                <p> &copy; LearnTech (Srinjoy) . All Rights Reserved | Terms And Conditions</p>
            </footer>
        </React.Fragment>
    )
};

export default Footer;