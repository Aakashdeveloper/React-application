import React from 'react';
import ReactDOM from 'react-dom';
import Router from './component/Router';

ReactDOM.render(<Router/>,document.getElementById('root'));
